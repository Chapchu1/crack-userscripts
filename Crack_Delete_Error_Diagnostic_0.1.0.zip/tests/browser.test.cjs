const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const runtime=require('./runtime.cjs');const pw=runtime.playwright(),chromium=runtime.req('@sparticuz/chromium').default;
const source=fs.readFileSync(path.join(__dirname,'../Crack_Delete_Error_Diagnostic.user.js'),'utf8');
const room='1234567890abcdef12345678';
test('native XHR deletion and download work without an extra network request',async()=>{
 const browser=await pw.chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/tmp/chromium',args:chromium.args,headless:true});try{
  const page=await browser.newPage({viewport:{width:412,height:900},acceptDownloads:true});page.setDefaultTimeout(5000);const calls=[];
  await page.route('https://crack.wrtn.ai/**',route=>route.fulfill({contentType:'text/html; charset=utf-8',body:'<!doctype html><div role="alertdialog"><h2>스토리 내용을 삭제하시겠어요?</h2><button id="delete">삭제</button></div>'}));
  await page.route('https://crack-api.wrtn.ai/**',route=>{const method=route.request().method();calls.push({method,body:route.request().postData()});return route.fulfill({status:method==='OPTIONS'?204:400,headers:{'access-control-allow-origin':'https://crack.wrtn.ai','access-control-allow-methods':'DELETE,GET','content-type':'application/json'},body:method==='OPTIONS'?'':JSON.stringify({message:'Invalid identifier format'})});});
  await page.goto('https://crack.wrtn.ai/stories/a/episodes/'+room);await page.addScriptTag({content:source});
  await page.click('#delete');await page.waitForSelector('#crack-delete-diagnostic-save');
  const native=await page.evaluate(room=>new Promise(resolve=>{const xhr=new XMLHttpRequest();xhr.open('DELETE','https://crack-api.wrtn.ai/crack-gen/v3/chats/'+room+'/messages/broken-id');xhr.onload=()=>resolve({status:xhr.status,text:xhr.responseText});xhr.send();}),room);
  assert.equal(native.status,400);assert.equal(JSON.parse(native.text).message,'Invalid identifier format');
  await page.waitForFunction(()=>JSON.parse(sessionStorage.getItem('crack-delete-diagnostic:v1')).report.events.some(e=>e.kind==='delete-response'));
  const download=page.waitForEvent('download');await page.click('#crack-delete-diagnostic-save');const d=await download;assert.equal(d.suggestedFilename(),'crack-delete-diagnostic.json');
  const report=JSON.parse(fs.readFileSync(await d.path(),'utf8'));assert.equal(report.events.at(-1).invalidIdentifier,true);assert.equal(report.events.at(-1).requestedId.kind,'other');assert.equal(calls.filter(c=>c.method==='DELETE').length,1);assert.equal(calls.filter(c=>c.method==='GET').length,0);
  const r=await page.locator('#crack-delete-diagnostic').boundingBox();assert.ok(r.x>=0&&r.x+r.width<=412&&r.y>=0);if(process.env.DIAGNOSTIC_SCREENSHOT)await page.screenshot({path:process.env.DIAGNOSTIC_SCREENSHOT});
 }finally{await browser.close();}
});
