const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {JSDOM}=require('./runtime.cjs').req('jsdom');
const {webcrypto}=require('node:crypto');
const source=fs.readFileSync(path.join(__dirname,'../Crack_Delete_Error_Diagnostic.user.js'),'utf8');
const ROOM='1234567890abcdef12345678',ID='abcdef1234567890abcdef12',TEMP='temp-1234-unsafe-id';
const URLBASE=`https://crack-api.wrtn.ai/crack-gen/v3/chats/${ROOM}/messages`;
async function setup(saved){
 const dom=new JSDOM(`<main><div data-message-group-id="${TEMP}"><div class="wrtn-markdown">secret private story</div></div><div role="alertdialog"><h2>스토리 내용을 삭제하시겠어요?</h2><button id="confirm">삭제</button></div></main>`,{url:`https://crack.wrtn.ai/stories/story/episodes/${ROOM}`,runScripts:'outside-only'});
 const w=dom.window;Object.defineProperty(w,'crypto',{value:webcrypto});w.TextEncoder=TextEncoder;w.Request=Request;w.Response=Response;w.Headers=Headers;
 const calls=[], downloads=[];let answer=new Response(JSON.stringify({message:'Invalid identifier format'}),{status:400,headers:{'content-type':'application/json'}});
 w.fetch=function(...args){calls.push(args);return Promise.resolve(answer);};const original=w.fetch;
 const target={_id:TEMP,chatId:ROOM,role:'assistant',parentTurnId:ID,content:'AI 답변 생성이 지연되어 요청을 완료하지 못했어요. secret private story',createdAt:'2026-10-26T00:54:00Z'};
 const store={getState:()=>({messages:new Map([[TEMP,target]]),messageGroups:[[TEMP]]})};
 const state={chatId:ROOM,status:'IDLE',selectedMessageId:TEMP};
 const root={stateNode:{}};root.stateNode.current=root;
 const context={memoizedProps:{value:state},return:root};const sf={memoizedProps:{value:store},return:context};
 const group=w.document.querySelector('[data-message-group-id]');group.__reactFiber$test={memoizedProps:{messageIds:[TEMP]},return:sf};
 w.document.querySelector('#confirm').__reactFiber$test={memoizedProps:{},return:sf};
 if(saved)for(const [k,v]of Object.entries(saved))w.sessionStorage.setItem(k,v);
 w.URL.createObjectURL=blob=>{downloads.push(blob);return 'blob:test';};w.URL.revokeObjectURL=()=>{};
 w.HTMLAnchorElement.prototype.click=function(){};
 w.eval(source);await wait();
 return {w,dom,calls,downloads,original,target,respond:r=>answer=r,click:()=>w.document.querySelector('#confirm').click(),save:()=>Object.fromEntries(Object.entries(w.sessionStorage)),close:()=>w.close()};
}
const wait=()=>new Promise(r=>setTimeout(r,60));
const report=async e=>{const b=e.w.document.querySelector('#crack-delete-diagnostic-save');assert.ok(b,'a confirmed deletion must make a diagnostic download available');b.click();await wait();assert.equal(e.downloads.length,1);return JSON.parse(await new Promise(resolve=>{const fr=new e.w.FileReader();fr.onload=()=>resolve(fr.result);fr.readAsText(e.downloads[0]);}));};

test('confirmation creates an anonymous client snapshot without sending any request',async()=>{const e=await setup();try{e.click();await wait();const r=await report(e);assert.equal(e.calls.length,0);assert.equal(r.events[0].kind,'confirm');assert.equal(r.events[0].client.target.id.kind,'temporary');assert.equal(r.events[0].client.target.role,'assistant');assert.ok(!JSON.stringify(r).includes(TEMP));assert.ok(!JSON.stringify(r).includes('secret private story'));assert.ok(!JSON.stringify(r).includes(ROOM));assert.ok(!JSON.stringify(r).includes('salt'));}finally{e.close();}});
test('failed DELETE response and original request are unchanged, with no automatic retry or GET',async()=>{const e=await setup();try{e.click();await wait();const opts={method:'DELETE',headers:{authorization:'Bearer PRIVATE-TOKEN'},credentials:'include'};const result=await e.w.fetch(URLBASE+'/'+TEMP,opts);assert.equal(result.status,400);assert.equal((await result.json()).message,'Invalid identifier format');await wait();assert.equal(e.calls.length,1);assert.equal(e.calls[0][0],URLBASE+'/'+TEMP);assert.equal(e.calls[0][1],opts);const r=await report(e);assert.equal(r.events.at(-1).kind,'delete-response');assert.equal(r.events.at(-1).invalidIdentifier,true);assert.ok(!JSON.stringify(r).includes('PRIVATE-TOKEN'));}finally{e.close();}});
test('redacted records survive refresh and a native GET provides comparable server identities',async()=>{const e=await setup();let saved;try{e.click();await wait();await e.w.fetch(URLBASE+'/'+TEMP,{method:'DELETE'});await wait();saved=e.save();assert.ok(!JSON.stringify(saved).includes('secret private story'));assert.ok(!JSON.stringify(saved).includes(TEMP));}finally{e.close();}const n=await setup(saved);try{n.respond(new Response(JSON.stringify({data:{messages:[{_id:ID,chatId:ROOM,role:'assistant',parentTurnId:ID,content:n.target.content}]}}),{status:200}));await n.w.fetch(URLBASE+'?limit=40');await wait();const r=await report(n);assert.equal(r.serverMessages.length,1);assert.equal(r.serverMessages[0].contentTag,r.events[0].client.target.contentTag);assert.equal(r.serverMessages[0].id.kind,'object-id');assert.equal(n.calls.length,1);}finally{n.close();}});
test('normal requests before a confirmed deletion have no capture or UI side effects',async()=>{const e=await setup();try{const input=URLBASE+'/'+ID,opts={method:'DELETE'};await e.w.fetch(input,opts);await wait();assert.equal(e.calls.length,1);assert.equal(e.w.document.querySelector('#crack-delete-diagnostic-save'),null);assert.equal(e.w.sessionStorage.length,0);}finally{e.close();}});
test('other hosts and rooms do not enter the report',async()=>{const e=await setup();try{e.click();await wait();await e.w.fetch('https://example.com/crack-gen/v3/chats/'+ROOM+'/messages/'+TEMP,{method:'DELETE'});await e.w.fetch(URLBASE.replace(ROOM,'aaaaaaaaaaaaaaaaaaaaaaaa')+'/'+TEMP,{method:'DELETE'});await wait();const r=await report(e);assert.equal(r.events.length,1);assert.equal(e.calls.length,2);}finally{e.close();}});
test('clear removes local diagnostic storage and download UI',async()=>{const e=await setup();try{e.click();await wait();const b=e.w.document.querySelector('#crack-delete-diagnostic-clear');assert.ok(b);b.click();await wait();assert.equal(e.w.sessionStorage.length,0);assert.equal(e.w.document.querySelector('#crack-delete-diagnostic-save'),null);}finally{e.close();}});

test('body-based message identifiers are recorded without copying other body fields',async()=>{const e=await setup();try{e.click();await wait();const body=JSON.stringify({messageId:TEMP,content:'DO NOT EXPORT MY CONTENT',token:'SECRET BODY TOKEN'});await e.w.fetch(URLBASE,{method:'DELETE',body});await wait();const r=await report(e);assert.equal(r.events.at(-1).bodyIds?.messageId?.kind,'temporary');assert.ok(!JSON.stringify(r).includes('DO NOT EXPORT'));assert.ok(!JSON.stringify(r).includes('SECRET BODY TOKEN'));assert.equal(e.calls[0][1].body,body);}finally{e.close();}});
