const fs=require('node:fs'),path=require('node:path'),{createRequire}=require('node:module');
const runtime=process.env.CDD_TEST_RUNTIME||(fs.existsSync(path.join(__dirname,'node_modules'))?path.join(__dirname,'package.json'):path.resolve(__dirname,'../../../work/theme-restyle/test-runtime/package.json'));
const req=createRequire(runtime);
module.exports={req,playwright:()=>{if(process.env.PLAYWRIGHT_MODULE)return require(process.env.PLAYWRIGHT_MODULE);try{return req('playwright');}catch{return require('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');}}};
